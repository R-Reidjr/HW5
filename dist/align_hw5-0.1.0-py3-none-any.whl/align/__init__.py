"""
BMI203: Biocomputing algorithms Winter 2022
Assignment 4: Needleman Wunsch
"""

from .align import NeedlemanWunsch, read_fasta

__version__ = '0.1.0'